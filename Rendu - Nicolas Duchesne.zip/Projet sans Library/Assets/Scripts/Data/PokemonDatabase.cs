using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewPokemonDatabase", menuName = "Database/Pokemon", order = 0)]

public class PokemonDatabase : ScriptableObject
{
    //A list that is our database of pokemons
    private List<PokemonData> datas = new();

    //The core function, it adds a new pokemon to the database by creating the PokemonData
    public void AddNewPokemon(string name, string sprite, int height, int weight, int pokedexNbr, string[] types, List<string> weaknesses, List<string> resistances, string desc, PokemonData.Stats stats)
    {

        if (datas.Exists(x => x.GetName() == name))
            return;

        PokemonData newPoke = new PokemonData(name, sprite, height, weight, pokedexNbr, types, weaknesses, resistances, desc, stats);

        datas.Add(newPoke);
    }

    //Sort the database by the pokedex number of the pokemons
    public void SortDatabaseByPokedexNbr()
    {
        datas.Sort((s1, s2) => s1.GetPokedexNbr().CompareTo(s2.GetPokedexNbr()));
    }

    //simple get function
    public List<PokemonData> GetDatas()
    {
        return datas;
    }

}
