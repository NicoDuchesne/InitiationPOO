using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class PokemonData
{
    //Our variable that will be shown in the fields
    [SerializeField] private string name;
    [SerializeField] private string sprite;
    [SerializeField] private int height;
    [SerializeField] private int weight;
    [SerializeField] private int pokedexNbr;
    [SerializeField] private string[] types;
    [SerializeField] private List<string> weaknesses;
    [SerializeField] private List<string> resistances;
    [SerializeField] private string desc;
    [SerializeField] private Stats stats;

    //our hidden variables
    private int sumStats;
    private int currentLife;
    private PokemonData pokemonOpponent;//the pokemon we will be fighting

    //Constructor with no parameters
    public PokemonData() { }

    //Constructor with almost all the variable as parameters
    public PokemonData(string name, string sprite, int height, int weight, int pokedexNbr, string[] types, List<string> weaknesses, List<string> resistances, string desc, Stats stats)
    {
        this.name = name;
        this.sprite = sprite;
        this.height = height;
        this.weight = weight;
        this.pokedexNbr = pokedexNbr;
        this.types = types;
        this.weaknesses = weaknesses;
        this.resistances = resistances;
        this.desc = desc;
        this.stats = stats;

        InitStatsPoints();
        InitCurrentLife();

        this.pokemonOpponent = new PokemonData();
    }

    //As asked the function InitStatsPoints, we initialize the sum of the stats, basic addition
    private void InitStatsPoints()
    {
        sumStats = stats.GetHp() + stats.GetAtk() + stats.GetDef() + stats.GetAtkSpe() + stats.GetDefSpe() + stats.GetSpeed();
    }

    //As asked the function InitCurrentLife, here we are supposed to say currentLife = stats.hp; but i found the fight would be more interesting this way
    private void InitCurrentLife()
    {
        currentLife = sumStats;
    }

    //As asked, the function TakeDamage taking a PokemonData as parameter that will inflicts dmg to the actual pokemon
    public void TakeDamage(PokemonData pokemonOpponent)
    {
        int dmg = 0;

        //let's take the higher atk as base dmg
        if (pokemonOpponent.stats.GetAtkSpe() > pokemonOpponent.stats.GetAtk())
        {
            dmg = pokemonOpponent.stats.GetAtkSpe();
        }
        else
        {
            dmg = pokemonOpponent.stats.GetAtk();
        }

        string attackingType = pokemonOpponent.types[0]; //An attack has only one type, we consider that it will be an attack of his primary type

        //calculation of the dmg
        foreach (string type in weaknesses)
        {
            if (type == attackingType)
                dmg *= 2;//super effective
        }

        foreach (string type in resistances)
        {
            if (type == attackingType)
                dmg /= 2;//not very effective
        }

        //the dmg is inflicted
        currentLife -= dmg;
        if (currentLife < 0)
        {
            currentLife = 0;
        }

        //output message
        Debug.Log($"{pokemonOpponent.name} attacks {this.name} inflicting {dmg} DMG, {this.name} has {currentLife} HPs remaining");
    }

    //As asked the function AttackOpponent that calls TakeDamage to work
    public void AttackOpponent()
    {
        pokemonOpponent.TakeDamage(this);
    }

    //As asked the function IsPokemonAlive to check if the pokemon is still alive or not
    public bool IsPokemonAlive()
    {
        return (currentLife > 0);
    }


    //Here we have a structure for the base statistics
    [Serializable]
    public struct Stats
    {
        //there are 6 stats in pokemon game
        private int hp;
        private int atk;
        private int atkSpe;
        private int def;
        private int defSpe;
        private int speed;

        //Constructor with the 6 stats
        public Stats(int hp, int atk, int def, int atkSpe, int defSpe, int speed)
        {
            this.hp = hp;
            this.atk = atk;
            this.def = def;
            this.atkSpe = atkSpe;
            this.defSpe = defSpe;
            this.speed = speed;
        }

        //All the get and set methods for stats
        public int GetHp()
        {
            return hp;
        }
        public int GetAtk()
        {
            return atk;
        }
        public int GetDef()
        {
            return def;
        }
        public int GetAtkSpe()
        {
            return atkSpe;
        }
        public int GetDefSpe()
        {
            return defSpe;
        }
        public int GetSpeed()
        {
            return speed;
        }

        public void SetHp(int hp)
        {
            this.hp = hp;
        }
        public void SetAtk(int atk)
        {
            this.atk = atk;
        }
        public void SetDef(int def)
        {
            this.def = def;
        }
        public void SetAtkSpe(int atkSpe)
        {
            this.atkSpe = atkSpe;
        }
        public void SetDefSpe(int defSpe)
        {
            this.defSpe = defSpe;
        }
        public void SetSpeed(int speed)
        {
            this.speed = speed;
        }

    }


    //the get and set methods that we will be using later
    public string GetName()
    {
        return name;
    }

    public string GetSprite()
    {
        return sprite;
    }

    public int GetHeight()
    {
        return height;
    }

    public int GetWeight()
    {
        return weight;
    }

    public int GetPokedexNbr()
    {
        return pokedexNbr;
    }

    public string[] GetTypes()
    {
        return types;
    }

    public string GetDesc()
    {
        return desc;
    }

    public Stats GetStats()
    {
        return stats;
    }

    public int GetSumStats()
    {
        return sumStats;
    }

    public void SetCurrentLife(int currentLife)
    {
        this.currentLife = currentLife;
    }

    public PokemonData GetPokemonOpponent()
    {
        return pokemonOpponent;
    }

    public void SetPokemonOpponent(PokemonData pokemonOpponent)
    {
        this.pokemonOpponent = pokemonOpponent;
    }





}


