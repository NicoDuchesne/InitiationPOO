using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using Button = UnityEngine.UI.Button;
using Image = UnityEngine.UI.Image;
using Random = System.Random;
using Slider = UnityEngine.UI.Slider;

public class PokemonInfosController : MonoBehaviour
{
    //VARIABLES

    //all the important variables shown in the fields, and they are displayed on the Canva
    [SerializeField] private RawImage imgIcon;
    [SerializeField] private Image imgTypeOne;
    [SerializeField] private Image imgTypeTwo;

    [SerializeField] private Text txtName;
    [SerializeField] private Text txtHeight;
    [SerializeField] private Text txtWeight;
    [SerializeField] private Text txtDesc;
    [SerializeField] private Text txtPokedexNbr;


    [SerializeField] private Text txtStatHp;
    [SerializeField] private Text txtStatAtk;
    [SerializeField] private Text txtStatDef;
    [SerializeField] private Text txtStatAtkSpe;
    [SerializeField] private Text txtStatDefSpe;
    [SerializeField] private Text txtStatSpeed;


    //Initialization for game objects and components that we will need later for some modifications
    private DatabaseManager databaseManager;
    private PokemonDatabase database;
    private List<PokemonData> pokemons;

    private Button btnPrev;
    private Button btnNext;
    private Button btnFirst;
    private Button btnLast;

    private Image imgDesc;
    private Image imgSearch;
    private Image imgResearch;

    private InputField iptSearch;
    private InputField iptResearch;

    private Slider sldHp;
    private Slider sldAtk;
    private Slider sldDef;
    private Slider sldAtkSpe;
    private Slider sldDefSpe;
    private Slider sldSpeed;

    private Dropdown dpdPokedex;

    //useful variables
    private bool dpdClicked = true;
    private bool isFightOver = true;

    private PokemonData currentPoke;
    private int pokeIndex;

    private float wait;
    private float delayAttack = 5f;

    //A dictionnary containing the pokemon types in string and their corresponding RGB codes
    IDictionary<string, byte[]> typeColors = new Dictionary<string, byte[]>()
    {
        { "bug",      new byte[3]{145,193,47 } },
        { "dark",     new byte[3]{90 ,84 ,101} },
        { "dragon",   new byte[3]{11 ,109,195} },
        { "electric", new byte[3]{244,210, 60} },
        { "fairy",    new byte[3]{236,143,230} },
        { "fighting", new byte[3]{206,65 ,107} },
        { "fire",     new byte[3]{255,157,85 } },
        { "flying",   new byte[3]{143,169,222} },
        { "ghost",    new byte[3]{82 ,105,173} },
        { "grass",    new byte[3]{99 ,188, 90} },
        { "ground",   new byte[3]{217,120, 69} },
        { "ice",      new byte[3]{115,206,192} },
        { "normal",   new byte[3]{145,154,162} },
        { "poison",   new byte[3]{170,107,200} },
        { "psychic",  new byte[3]{250,113,121} },
        { "rock",     new byte[3]{197,183,140} },
        { "steel",    new byte[3]{90 ,142,162} },
        { "water",    new byte[3]{80 ,144,214} },
    };

    //As asked an enumerator wit hall the pokemon types, I will never call it because it's useless for my solution, but it was required in the exercise
    private enum Types
    {
        Bug,
        Dark,
        Dragon,
        Electric,
        Fairy,
        Fighting,
        Fire,
        Flying,
        Ghost,
        Grass,
        Ground,
        Ice,
        Normal,
        Poison,
        Psychic,
        Rock,
        Steel,
        Water,
        None
    };


    //UNITY CALLS

    private void Awake()
    {
        //we assign some usefull variable for later about databases
        databaseManager = FindObjectOfType<DatabaseManager>();
        database = databaseManager.GetDatabaseByIndex(0);
        pokemons = database.GetDatas();

        //We search for the components of the gameObjects that we will interact with
        btnPrev = GameObject.Find("previous").GetComponent<Button>();
        btnNext = GameObject.Find("next").GetComponent<Button>();
        btnFirst = GameObject.Find("first").GetComponent<Button>();
        btnLast = GameObject.Find("last").GetComponent<Button>();

        imgDesc = GameObject.Find("descBg").GetComponent<Image>();
        imgSearch = GameObject.Find("Search").GetComponent<Image>();
        imgResearch = GameObject.Find("Research").GetComponent<Image>();

        iptSearch = GameObject.Find("Search").GetComponent<InputField>();
        iptResearch = GameObject.Find("Research").GetComponent<InputField>();

        sldHp = GameObject.Find("SliderHP").GetComponent<Slider>();
        sldAtk = GameObject.Find("SliderATK").GetComponent<Slider>();
        sldDef = GameObject.Find("SliderDEF").GetComponent<Slider>();
        sldAtkSpe = GameObject.Find("SliderATKSPE").GetComponent<Slider>();
        sldDefSpe = GameObject.Find("SliderDEFSPE").GetComponent<Slider>();
        sldSpeed = GameObject.Find("SliderSPEED").GetComponent<Slider>();

        dpdPokedex = GameObject.Find("pokedex").GetComponent<Dropdown>();
    }


    private void Start()
    {
        //At first, we go to the first pokemon of the first generation
        pokeIndex = 0;
        StartCoroutine(LaunchDelayed());
    }


    private void Update()
    {
        //As asked, we make a delay attack, so that the pokemon in the fight will atack every 1.25 to 3.1 sec
        if (Time.time > delayAttack && !isFightOver)
        {
            Random seed = new Random();
            int temp = seed.Next(125, 311);
            wait = (float)temp / 100;
            delayAttack = Time.time + wait;

            Fight();//the pokemon will attack
        }
    }

    //The database and the API calls take some time at launch, before accessing to our first pokemon, we wait a bit
    IEnumerator LaunchDelayed()
    {
        yield return new WaitForSeconds(2f);
        ChangePokemon(pokemons[pokeIndex]);
    }

    private void Fight()
    {
        //We check the status befire attacking, then our pokemon displayed will attack his opponent, and then the opponent strikes back
        if (currentPoke.GetPokemonOpponent().IsPokemonAlive() && currentPoke.IsPokemonAlive())
        {
            currentPoke.AttackOpponent();

            if (currentPoke.GetPokemonOpponent().IsPokemonAlive() && currentPoke.IsPokemonAlive())
            {
                currentPoke.TakeDamage(currentPoke.GetPokemonOpponent());

                if (!currentPoke.IsPokemonAlive())
                {
                    Debug.Log($"Our {currentPoke.GetName()} is KO ! The fight is over");
                    isFightOver = true;
                }

            }
            else
            {
                Debug.Log($"The opponent Pokemon {currentPoke.GetPokemonOpponent().GetName()} is KO ! The fight is over");
                isFightOver = true;
            }
        }
    }






    //PRINCIPAL FUNCTION CHANGEPOKEMON

    //changePokemon changes the pokemon displayed with the pokemonData given
    private void ChangePokemon(PokemonData pokemon)
    {
        currentPoke = pokemon;

        //We change the images
        StartCoroutine(DisplayIcon());
        DisplayTypes();

        //and the texts
        DisplayName();
        DisplayHeight();
        DisplayWeight();
        DisplayPokedexNbr();
        DisplayDesc();

        //the stats
        DisplayStats();


        //these functions change the display of gameobjects to make the whole better
        DisplayButtons();
        DisplayInputFieldS();
        DisplayDescription();
        DisplaySliders();

        //We do some initialization stuff for the fight
        GiveOpponent();
        RestoreLifes();
        isFightOver = false;
    }

    //FUNCTIONS USED IN CHANGEPOKEMON
    IEnumerator DisplayIcon()
    {
        //get the sprite now
        UnityWebRequest pokeSpriteRequest = UnityWebRequestTexture.GetTexture(currentPoke.GetSprite());
        yield return pokeSpriteRequest.SendWebRequest();
        if (pokeSpriteRequest.result == UnityWebRequest.Result.ConnectionError || pokeSpriteRequest.result == UnityWebRequest.Result.ProtocolError)
        {
            Debug.LogError(pokeSpriteRequest.error);
            yield break;
        }

        //we put the sprite in the icon
        imgIcon.texture = DownloadHandlerTexture.GetContent(pokeSpriteRequest);
    }

    private void DisplayTypes()
    {
        //we display the corresponding types' images for the types
        imgTypeOne.sprite = Resources.Load<Sprite>(currentPoke.GetTypes()[0]);
        if (currentPoke.GetTypes().Length > 1)// if he has a secondary type
        {
            imgTypeTwo.sprite = Resources.Load<Sprite>(currentPoke.GetTypes()[1]);
        }
        else
        {
            imgTypeTwo.sprite = Resources.Load<Sprite>("none");
        }
    }

    //simply display the name in a nice way
    private void DisplayName()
    {
        string output = currentPoke.GetName();
        output = char.ToUpper(output[0]) + output.Substring(1);
        txtName.text = $"Name : {output} ";
    }


    private void DisplayHeight()
    {
        string output = currentPoke.GetHeight().ToString();
        //the data for height is a bit weird, the comas are missing
        if (output.Length == 1)
        {
            output = output.Insert(0, "0,");
        }
        else
        {
            output = output.Insert(output.Length - 1, ",");
        }

        txtHeight.text = $"Heigth : {output} m ";
    }

    private void DisplayWeight()
    {
        string output = currentPoke.GetWeight().ToString();
        //same for weight, we add the comas
        if (output.Length == 1)
        {
            output = output.Insert(0, "0,");
        }
        else
        {
            output = output.Insert(output.Length - 1, ",");
        }

        txtWeight.text = $"Weigth : {output} kg ";
    }

    private void DisplayPokedexNbr()
    {
        string output = currentPoke.GetPokedexNbr().ToString();
        int length = output.Length;

        //we want to display the pokedex number in a nice way like that : #0001
        for (int i = 0; i < 4 - length; i++)
        {
            output = output.Insert(0, "0");
        }
        output = output.Insert(0, "#");

        txtPokedexNbr.text = output;
    }

    //simply display the pokdex description
    private void DisplayDesc()
    {
        txtDesc.text = currentPoke.GetDesc();
    }

    //Simply display the 6 statistics
    private void DisplayStats()
    {
        txtStatHp.text = $"HP : {DisplayStat(currentPoke.GetStats().GetHp())}";
        txtStatAtk.text = $"ATK : {DisplayStat(currentPoke.GetStats().GetAtk())}";
        txtStatDef.text = $"DEF : {DisplayStat(currentPoke.GetStats().GetDef())}";
        txtStatAtkSpe.text = $"ATK SPE : {DisplayStat(currentPoke.GetStats().GetAtkSpe())}";
        txtStatDefSpe.text = $"DEF SPE : {DisplayStat(currentPoke.GetStats().GetDefSpe())}";
        txtStatSpeed.text = $"SPEED : {DisplayStat(currentPoke.GetStats().GetSpeed())}";
    }

    //We work the stats' strings to be exactly 3 chars long, it will display nicer
    private string DisplayStat(int x)
    {
        string output = x.ToString();
        int length = output.Length;

        for (int i = 0; i < 3 - length; i++)
        {
            output = output.Insert(0, " ");
        }

        return output;
    }

    //We give a random pokemon as the oppponent of our actual pokemon displayed
    private void GiveOpponent()
    {
        Random seed = new Random();
        int number = seed.Next(1, 1026);

        for (int i = 0; i < databaseManager.databases.Count; i++)
        {
            foreach (PokemonData pokemon in databaseManager.databases[i].GetDatas())
            {
                if (pokemon.GetPokedexNbr() == number)
                {
                    currentPoke.SetPokemonOpponent(pokemon);
                    goto LoopEnd;
                }

            }
        }
    LoopEnd:;
    }

    //This function is used to restore the Hps of our pokemon and his opponent to their initial state
    private void RestoreLifes()
    {
        currentPoke.SetCurrentLife(currentPoke.GetSumStats());
        currentPoke.GetPokemonOpponent().SetCurrentLife(currentPoke.GetPokemonOpponent().GetSumStats());
    }

    //DisplayButton will disable/enable the buttons when needed
    private void DisplayButtons()
    {
        //if we only have one pokemon
        if (pokeIndex == 0 && pokeIndex == pokemons.Count - 1)
        {
            btnPrev.interactable = false;
            btnNext.interactable = false;
            btnFirst.interactable = false;
            btnLast.interactable = false;
        }
        //on the first pokemon, you shouldn't be able to go backward
        else if (pokeIndex == 0)
        {
            btnPrev.interactable = false;
            btnNext.interactable = true;
            btnFirst.interactable = false;
            btnLast.interactable = true;
        }
        //and on the last you shouldnt go forward
        else if (pokeIndex == pokemons.Count - 1)
        {
            btnNext.interactable = false;
            btnPrev.interactable = true;
            btnLast.interactable = false;
            btnFirst.interactable = true;
        }
        //but on regular pokemon, everything is possible
        else
        {
            btnPrev.interactable = true;
            btnNext.interactable = true;
            btnLast.interactable = true;
            btnFirst.interactable = true;
        }
    }

    //displayInputFields resets the changes applied to the inputfields
    private void DisplayInputFieldS()
    {
        imgSearch.color = Color.white;
        imgResearch.color = Color.white;
        iptSearch.text = "";
        iptResearch.text = "";
    }

    //displayDescription is used to change the background color of the description based on the pokemon type
    private void DisplayDescription()
    {
        string type = pokemons[pokeIndex].GetTypes()[0];

        imgDesc.color = new Color32(typeColors[type][0], typeColors[type][1], typeColors[type][2], 255);
    }

    //displaySlider will change the sliders value accordingly to the pokemon stats
    private void DisplaySliders()
    {
        sldHp.value = currentPoke.GetStats().GetHp();
        sldAtk.value = currentPoke.GetStats().GetAtk();
        sldDef.value = currentPoke.GetStats().GetDef();
        sldAtkSpe.value = currentPoke.GetStats().GetAtkSpe();
        sldDefSpe.value = currentPoke.GetStats().GetDefSpe();
        sldSpeed.value = currentPoke.GetStats().GetSpeed();
    }


    //PUBLIC PROCEDURES CALLED BY THE UI ELEMENTS IN UNITY

    //nextPokemon() is called when clicking on the corresponding button, will go to the next pokemon in DB
    public void NextPokemon()
    {
        RestoreLifes();
        pokeIndex += 1;
        ChangePokemon(pokemons[pokeIndex]);
    }

    //prevPokemon() is called when clicking on the corresponding button, will go to the previous pokemon in DB
    public void PrevPokemon()
    {
        RestoreLifes();
        pokeIndex -= 1;
        ChangePokemon(pokemons[pokeIndex]);
    }

    //firstPokemon() is called when clicking on the corresponding button, will go to the first pokemon in DB
    public void FirstPokemon()
    {
        RestoreLifes();
        pokeIndex = 0;
        ChangePokemon(pokemons[pokeIndex]);
    }

    //lastPokemon() is called when clicking on the corresponding button, will go to the last pokemon in DB
    public void LastPokemon()
    {
        RestoreLifes();
        pokeIndex = pokemons.Count - 1;
        ChangePokemon(pokemons[pokeIndex]);
    }

    //lastPokemon() is called when clicking on the corresponding button, will go to a random pokemon in all databases
    public void RandomPokemon()
    {
        //randomisation of a pokedex number
        Random seed = new Random();
        int number = seed.Next(1, 1026);

        //we search for the pokemon
        for (int i = 0; i < databaseManager.databases.Count; i++)
        {
            foreach (PokemonData pokemon in databaseManager.databases[i].GetDatas())
            {
                if (pokemon.GetPokedexNbr() == number)
                {
                    database = databaseManager.databases[i];
                    pokemons = database.GetDatas();
                    pokeIndex = pokemons.IndexOf(pokemon);
                    RestoreLifes();
                    ChangePokemon(pokemons[pokeIndex]);
                    dpdClicked = false;
                    dpdPokedex.value = i;
                    goto LoopEnd;
                }

            }
        }
    LoopEnd:
        dpdClicked = true;
    }

    //searchPokemon() called when on submit of the corresponding input field, will find the pokemon with a given pokedex number
    public void SearchByNbr(string s)
    {

        string input = s;
        string pattern = "^[#]?[0-9]+$";//we will only test the strings that pass the regex
        MatchCollection matches = Regex.Matches(input, pattern);


        if (matches.Count == 1)//if the regex is passed
        {
            int count = 0;
            for (int i = 0; i < input.Length; i++)//with this loop, we want to output a string suitable for an index
            {
                if (input[i].ToString().Equals("#") || input[i].ToString().Equals("0"))
                {
                    count += 1;
                }
                else
                {
                    break;
                }
            }
            input = input.Remove(0, count);
            if (input == null || input.Length == 0 || input == "0")
                input = "-1";
            int number = Int32.Parse(input);//here is the final var for index

            //we search for the pokemon
            for (int i = 0; i < databaseManager.databases.Count; i++)
            {
                foreach (PokemonData pokemon in databaseManager.databases[i].GetDatas())
                {
                    if (pokemon.GetPokedexNbr() == number)//found
                    {
                        database = databaseManager.databases[i];
                        pokemons = database.GetDatas();
                        pokeIndex = pokemons.IndexOf(pokemon);
                        RestoreLifes();
                        ChangePokemon(pokemons[pokeIndex]);
                        dpdClicked = false;
                        dpdPokedex.value = i;
                        goto LoopEnd;
                    }
                }
            }


        }

        imgSearch.color = Color.red;//not found, feedback when the input given is wrong

    LoopEnd:
        dpdClicked = true;
    }

    //researchPokemon() called when on submit of the corresponding input field, will find the pokemon with a given pokemon name, very similar to searchPokemon()
    public void SearchByname(string s)
    {

        string input = s;
        string pattern = "^[a-zA-Z0-9-]+$";//we will only test the string that passes the regex
        MatchCollection matches = Regex.Matches(input, pattern);

        if (matches.Count == 1)//the regex is passed
        {
            input = input.ToLower();//we put it to the good format

            //we search for the pokemon
            for (int i = 0; i < databaseManager.databases.Count; i++)
            {
                foreach (PokemonData pokemon in databaseManager.databases[i].GetDatas())
                {
                    if (pokemon.GetName() == input)//found
                    {
                        database = databaseManager.databases[i];
                        pokemons = database.GetDatas();
                        pokeIndex = pokemons.IndexOf(pokemon);
                        RestoreLifes();
                        ChangePokemon(pokemons[pokeIndex]);
                        dpdClicked = false;
                        dpdPokedex.value = i;
                        goto LoopEnd;
                    }

                }
            }


        }

        imgResearch.color = Color.red;//not found, feedback when the input given is wrong

    LoopEnd:
        dpdClicked = true;
    }

    //chooseGeneration() will switch beetween the pokemon Database with the corresponding dropdown menu, each database represents a generation
    public void ChooseGeneration(int gen)
    {
        if (dpdClicked)//we are using dpdClicked primarly for this function, so that it activates only when the dropdown value is changed by a real click and not our code
        {
            pokeIndex = 0;
            database = databaseManager.GetDatabaseByIndex(gen);
            pokemons = database.GetDatas();
            RestoreLifes();
            ChangePokemon(pokemons[pokeIndex]);
        }
    }




}
