using SimpleJSON;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class DatabaseManager : MonoBehaviour
{
    //A list of the databases, where we will stock the 9 databases for the 9 generations of pokemon
    public List<PokemonDatabase> databases = new List<PokemonDatabase>();
    //The number of pokemons in each generation/database
    private List<int> pokemonCount = new List<int> { 0, 151, 251, 386, 494, 649, 721, 809, 905, 1025 };
    //the base of the url used in the PokeAPI
    private readonly string basePokeURL = "https://pokeapi.co/api/v2/";

    private void Awake()
    {
        RefillDatabases();//In awake, we refill the datbases 
    }

    private void Start()
    {
        sortDatabases();//And in start we sort them
    }

    //RefillDatabases refills the 9 databases by using the number of pokemon by generation
    public void RefillDatabases()
    {
        for (int i = 0; i < databases.Count; i++)
        {
            //databases[i].GetDatas().Clear(); //if we want to redownload the datas again
            if (databases[i].GetDatas().Count != pokemonCount[i + 1] - pokemonCount[i])
            {
                StartCoroutine(AddPokemoninDbByRange(pokemonCount[i] + 1, pokemonCount[i + 1], databases[i]));
            }
        }
    }

    //Sort the 9 databases by pokedex number
    public void sortDatabases()
    {
        for (int i = 0; i < databases.Count; i++)
        {
            databases[i].SortDatabaseByPokedexNbr();
        }
    }


    //This will add the pokemon in the database beetween from pokedex number start and to pokedex number stop stop, using the PokeAPI to retieve all the data
    IEnumerator AddPokemoninDbByRange(int start, int stop, PokemonDatabase database)
    {
        for (int i = start; i <= stop; i++)
        {

            int pokemonIndex = i;

            //Request URL of the index pokemon
            string pokemonURL = basePokeURL + "pokemon/" + pokemonIndex.ToString();

            //Send Webrequest
            UnityWebRequest pokeInfoRequest = UnityWebRequest.Get(pokemonURL);
            yield return pokeInfoRequest.SendWebRequest();

            //Check if any error and breaks if there is one
            if (pokeInfoRequest.result == UnityWebRequest.Result.ConnectionError || pokeInfoRequest.result == UnityWebRequest.Result.ProtocolError)
            {
                Debug.LogError(pokeInfoRequest.error);
                yield break;
            }

            JSONNode pokeInfo = JSON.Parse(pokeInfoRequest.downloadHandler.text);//pokemon infos

            //we get his name 
            string pokeName = pokeInfo["name"];

            //we get his height
            int pokeHeight = pokeInfo["height"];

            //we get his weight
            int pokeWeight = pokeInfo["weight"];

            //we get his pokedex number
            int pokeNbr = pokeInfo["id"];

            //We get the stats
            PokemonData.Stats pokeStats = new PokemonData.Stats();
            JSONNode stats = pokeInfo["stats"];
            pokeStats.SetHp(stats[0]["base_stat"]);
            pokeStats.SetAtk(stats[1]["base_stat"]);
            pokeStats.SetDef(stats[2]["base_stat"]);
            pokeStats.SetAtkSpe(stats[3]["base_stat"]);
            pokeStats.SetDefSpe(stats[4]["base_stat"]);
            pokeStats.SetSpeed(stats[5]["base_stat"]);

            //we get the types 
            JSONNode types = pokeInfo["types"];
            string[] pokeTypes = new string[types.Count];

            for (int x = 0; x < types.Count; x++)
            {
                pokeTypes[x] = types[x]["type"]["name"];
            }


            //We want Weaknesses and resistances
            List<string> pokeWeaknesses = new List<string>();
            List<string> pokeResitances = new List<string>();

            for (int x = 0; x < types.Count; x++)
            {
                //New request about the Types infos
                string pokemonTypeURL = types[x]["type"]["url"];
                UnityWebRequest pokeTypesRequest = UnityWebRequest.Get(pokemonTypeURL);
                yield return pokeTypesRequest.SendWebRequest();
                if (pokeTypesRequest.result == UnityWebRequest.Result.ConnectionError || pokeTypesRequest.result == UnityWebRequest.Result.ProtocolError)
                {
                    Debug.LogError(pokeTypesRequest.error);
                    yield break;
                }

                JSONNode pokeTypesInfos = JSON.Parse(pokeTypesRequest.downloadHandler.text);//Types info

                //we search and store the weaknesses/resistances
                foreach (KeyValuePair<string, SimpleJSON.JSONNode> type in pokeTypesInfos["damage_relations"]["double_damage_from"])
                {
                    pokeWeaknesses.Add(type.Value[0]);

                }

                foreach (KeyValuePair<string, SimpleJSON.JSONNode> type in pokeTypesInfos["damage_relations"]["half_damage_from"])
                {
                    pokeResitances.Add(type.Value[0]);
                }
            }


            //We also want a pokedex description, we will need another request
            string pokemonSpeciesURL = basePokeURL + "pokemon-species/" + pokemonIndex.ToString();
            UnityWebRequest pokeSpeciesRequest = UnityWebRequest.Get(pokemonSpeciesURL);
            yield return pokeSpeciesRequest.SendWebRequest();
            if (pokeSpeciesRequest.result == UnityWebRequest.Result.ConnectionError || pokeSpeciesRequest.result == UnityWebRequest.Result.ProtocolError)
            {
                Debug.LogError(pokeSpeciesRequest.error);
                yield break;
            }

            JSONNode pokeSpecies = JSON.Parse(pokeSpeciesRequest.downloadHandler.text);//Pokemon Species infos

            //We get the pokedex description
            string pokeDesc = "There was an error while retrieving the pokedex entry. Also Happens when the pokemon is recent";
            for (int x = 0; x < pokeSpecies["flavor_text_entries"].Count; x++)
            {
                if (pokeSpecies["flavor_text_entries"][x]["language"]["name"] == "en")//get the first pokedex entry that is in english 
                {
                    pokeDesc = pokeSpecies["flavor_text_entries"][x]["flavor_text"];
                    break;
                }
            }
            pokeDesc = pokeDesc.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ").Replace("\f", " ").Replace("POK�MON", "Pok�mon");

            //finally we build the URL containing our pokemon sprite, it's not from the API, it is the sprites from the official pokedex website
            string pokeSpriteURL = "https://assets.pokemon.com/assets/cms2/img/pokedex/full/";
            int length = pokeNbr.ToString().Length;
            string aux = pokeNbr.ToString();

            if (length < 3) //the pokedex number in the url must be 3 or 4 for characters long
            {
                for (int x = 0; x < 3 - length; x++)
                {
                    aux = aux.Insert(0, "0");
                }
            }
            pokeSpriteURL += aux + ".png";

            


            //now we have all the infos to create and add a new pokemon to the database
            database.AddNewPokemon(pokeName, pokeSpriteURL, pokeHeight, pokeWeight, pokeNbr, pokeTypes, pokeWeaknesses, pokeResitances, pokeDesc, pokeStats);

        }

    }

    //Get a database by a given index, very useful for switching generations and for the dropdown menu
    public PokemonDatabase GetDatabaseByIndex(int index)
    {
        return databases[index];
    }
}
